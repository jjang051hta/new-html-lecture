package com.jjang051.phone;

public class PhoneTest {
    public static void main(String[] args) {
        PhoneInterface galaxy = new GalaxyNote();
    }
}
