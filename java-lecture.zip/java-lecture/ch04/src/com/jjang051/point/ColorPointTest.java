package com.jjang051.point;

public class ColorPointTest {
    public static void main(String[] args) {
        ColorPoint cp = new ColorPoint(10, 10, "red");
        cp.showPoint();
        cp.showColorPoint();
    }
}
