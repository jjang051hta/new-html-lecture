package com.jjang051.tv;

public class TV {
    private int size;

    public TV() {
    }

    public TV(int size) {
        this.size = size;
    }

    public int getSize() {
        return size;
    }
}
