public class Student extends Person {
    public void set() {
        age = 30;
        height = 180;
        name = "장성호";
        setWeight(80);
    }
}
