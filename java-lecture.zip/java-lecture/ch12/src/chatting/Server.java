package chatting;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Server extends JFrame {
    private JTextArea log = new JTextArea(20, 30);
    private JLabel userLabel = new JLabel();

    public Server() {
        super("멀티 채팅");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 프레임 종료 버튼(X)을 클릭하면 프로그램 종료
        Container c = getContentPane();
        log.setBackground(Color.GREEN);
        c.add(new JScrollPane(log), BorderLayout.CENTER);
        userLabel.setText("현재 접속자수는 0명 입니다.");
        c.add(userLabel, BorderLayout.SOUTH);
        this.pack();
        this.setResizable(false);
        setVisible(true);

    }

    class ServerThread extends Thread {
        @Override
        public void run() {
            ServerSocket listener = null;
            Socket socket = null;
            try {
                listener = new ServerSocket(9998);
                while (true) {
                    socket = listener.accept();
                    log.append("클라이언트 연결됨\n");
                    new ServiceThread(socket).start();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                if (listener != null)
                    listener.close();
                if (socket != null)
                    socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        new Server();
    }
}
