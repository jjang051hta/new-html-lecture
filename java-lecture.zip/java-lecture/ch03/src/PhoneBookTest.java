public class PhoneBookTest {
    public static void main(String[] args) {
        PhoneBook myPhoneBook = new PhoneBook();
        myPhoneBook.write();
        myPhoneBook.run();
    }
}
