public class App {
    public static void main(String[] args) throws Exception {
        int age = 848939403;
        long big = 8489394030l;
        double weight = 80.5;
        float myWeight = 80.00939f;
        // age = 21;
        String myName = "장성호";
        // String은 레펀런스 타입인데 기본 타입처럼 사용
        System.out.println(age);
        System.out.println(weight);
    }
}
