public class LogicalTest {
    public static void main(String[] args) {
        // 절대값
        System.out.println('a' > 'b');
        System.out.println(3 > 2); // 크다
        System.out.println(-1 < 0); // 작다
        System.out.println(3.14 <= 2); // 작거나 같다
        System.out.println(3 == 2); // 같다
        System.out.println(3 != 2); // 다르다
        System.out.println(!(3 != 2)); // 다르다
        System.out.println(3 > 2 && 3 > 4); // 다르다
        System.out.println(3 > 2 || 3 > 4); // 다르다

    }
}
