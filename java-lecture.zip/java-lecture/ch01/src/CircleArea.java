public class CircleArea {
    public static void main(String[] args) {
        final double PI = 3.14;
        double radius = 3.5;
        int myMoney = 1_000_000;
        double circleArea = radius * radius * PI;
        // boolean isTrue = null;
        var num = 10;
        num++;
        var nickName = "장동건"; // 타입추론
        String myName = null;
        System.out.println(circleArea);
        System.out.println(myMoney);
        System.out.println(num);
    }
}
