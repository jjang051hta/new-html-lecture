package app;

public class App {
    public static void main(String[] args) {
        SamsungCalculator samsungCalculator = new SamsungCalculator();
        int result = samsungCalculator.add(10, 20);
        Math.abs(3);
        System.out.println(result);
    }
}
